var searchData=
[
  ['gestionerubrica_0',['GestioneRubrica',['../classgestionerubrica_1_1_gestione_rubrica.html',1,'gestionerubrica']]],
  ['gruppo_1',['Gruppo',['../classclassi_gestione_rubrica_1_1_gruppo.html',1,'classiGestioneRubrica']]]
];
