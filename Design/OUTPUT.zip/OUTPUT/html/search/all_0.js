var searchData=
[
  ['archivio_0',['Archivio',['../classclassi_gestione_rubrica_1_1_archivio.html',1,'classiGestioneRubrica']]]
];
