var searchData=
[
  ['interfacciarubrica_0',['InterfacciaRubrica',['../interfaceclassi_gestione_rubrica_1_1_interfaccia_rubrica.html',1,'classiGestioneRubrica']]]
];
