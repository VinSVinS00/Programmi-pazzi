var searchData=
[
  ['main_0',['main',['../classgestionerubrica_1_1_gestione_rubrica.html#a0a3928bae6d691a505662a539b5bc5f8',1,'gestionerubrica::GestioneRubrica']]]
];
