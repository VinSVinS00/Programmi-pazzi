var searchData=
[
  ['contatto_0',['Contatto',['../classclassi_gestione_rubrica_1_1_contatto.html',1,'classiGestioneRubrica']]]
];
