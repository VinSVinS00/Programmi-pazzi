var indexSectionsWithContent =
{
  0: "acgimr",
  1: "acgir",
  2: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "Funzioni"
};

