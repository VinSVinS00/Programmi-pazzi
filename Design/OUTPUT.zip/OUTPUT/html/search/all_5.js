var searchData=
[
  ['rubrica_0',['Rubrica',['../classclassi_gestione_rubrica_1_1_rubrica.html',1,'classiGestioneRubrica']]]
];
