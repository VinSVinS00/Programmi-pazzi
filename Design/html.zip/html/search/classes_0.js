var searchData=
[
  ['app_0',['App',['../class_applicazione_1_1_app.html',1,'Applicazione']]],
  ['archiviocontroller_1',['ArchivioController',['../class_applicazione_1_1_archivio_controller.html',1,'Applicazione']]]
];
