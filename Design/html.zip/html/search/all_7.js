var searchData=
[
  ['rimuovi_0',['rimuovi',['../class_applicazione_1_1_preferiti_controller.html#abd8c3d73442ae6e99678d8fb714c31bb',1,'Applicazione::PreferitiController']]],
  ['ritorna_1',['ritorna',['../class_applicazione_1_1_archivio_controller.html#a356573449d0014db13e063d8b6c3fdff',1,'Applicazione.ArchivioController.ritorna()'],['../class_applicazione_1_1_mostra_controller.html#a8be17e01e755c8bb16a4e7b71665aef9',1,'Applicazione.MostraController.ritorna()'],['../class_applicazione_1_1_preferiti_controller.html#a1b1704dc3ff22eebdafe490d476070b4',1,'Applicazione.PreferitiController.ritorna()']]],
  ['rubricacontroller_2',['RubricaController',['../class_applicazione_1_1_rubrica_controller.html',1,'Applicazione']]]
];
