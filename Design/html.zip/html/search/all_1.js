var searchData=
[
  ['contatto_0',['Contatto',['../class_applicazione_1_1_contatto.html',1,'Applicazione.Contatto'],['../class_applicazione_1_1_contatto.html#a418c15a56094544c4967ee3aad9b1032',1,'Applicazione.Contatto.Contatto()']]],
  ['contattocontroller_1',['ContattoController',['../class_applicazione_1_1_contatto_controller.html',1,'Applicazione']]]
];
