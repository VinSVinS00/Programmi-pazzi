var searchData=
[
  ['add_0',['add',['../class_applicazione_1_1_rubrica_controller.html#af4dbd4f156fe32d622bf4b6fa90bc1d6',1,'Applicazione::RubricaController']]],
  ['annulla_1',['annulla',['../class_applicazione_1_1_contatto_controller.html#a32845dcbf72c8ad5ec9f6dd544bf70ec',1,'Applicazione.ContattoController.annulla()'],['../class_applicazione_1_1_modifica_controller.html#af44b01d1058bb4a84f64203dcb9e9dbf',1,'Applicazione.ModificaController.annulla()']]],
  ['archivia_2',['archivia',['../class_applicazione_1_1_archivio_controller.html#a20dbc863bc37110c326958b35fcc1148',1,'Applicazione.ArchivioController.archivia()'],['../class_applicazione_1_1_rubrica_controller.html#a9ed1d907a5502e06f18cde5dc7f9232a',1,'Applicazione.RubricaController.archivia()']]]
];
