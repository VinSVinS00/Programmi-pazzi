var searchData=
[
  ['preferiti_0',['preferiti',['../class_applicazione_1_1_modifica_controller.html#a48570d53835fb7d26dd51eb1090386f8',1,'Applicazione.ModificaController.preferiti()'],['../class_applicazione_1_1_rubrica_controller.html#ac46f8d8c49070e081dde67956580d1fe',1,'Applicazione.RubricaController.preferiti()']]]
];
