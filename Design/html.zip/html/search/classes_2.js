var searchData=
[
  ['modificacontroller_0',['ModificaController',['../class_applicazione_1_1_modifica_controller.html',1,'Applicazione']]],
  ['mostracontroller_1',['MostraController',['../class_applicazione_1_1_mostra_controller.html',1,'Applicazione']]]
];
