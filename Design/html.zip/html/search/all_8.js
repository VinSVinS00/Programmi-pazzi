var searchData=
[
  ['salva_0',['salva',['../class_applicazione_1_1_contatto_controller.html#a6f77b53992bea3e5974fb82875a245c2',1,'Applicazione::ContattoController']]],
  ['setcognome_1',['setCognome',['../class_applicazione_1_1_contatto.html#a6905bdc9cf32d2d2ba967bd95c98c64f',1,'Applicazione::Contatto']]],
  ['setcontats_2',['setContats',['../class_applicazione_1_1_rubrica_controller.html#a989898226ad8b76e855ec2c0ecb60723',1,'Applicazione::RubricaController']]],
  ['setmail_3',['setMail',['../class_applicazione_1_1_contatto.html#a66f5f6b202404786686eb4b80efc9602',1,'Applicazione::Contatto']]],
  ['setmail2_4',['setMail2',['../class_applicazione_1_1_contatto.html#ae8f57d2b4ef69e2c0ae2dafe78913cdf',1,'Applicazione::Contatto']]],
  ['setmail3_5',['setMail3',['../class_applicazione_1_1_contatto.html#a483355a182a9050d998552d7744564da',1,'Applicazione::Contatto']]],
  ['setnome_6',['setNome',['../class_applicazione_1_1_contatto.html#aa7c4db0f188e3652227a934b3c01c757',1,'Applicazione::Contatto']]],
  ['setnumero_7',['setNumero',['../class_applicazione_1_1_contatto.html#a891c35440df550c5e888e26b070f66f5',1,'Applicazione::Contatto']]],
  ['setnumero2_8',['setNumero2',['../class_applicazione_1_1_contatto.html#a2ed9f4970caa64b0489447a2e35a3e7f',1,'Applicazione::Contatto']]],
  ['setnumero3_9',['setNumero3',['../class_applicazione_1_1_contatto.html#ad0405d9570eaf305b2c9d753e4c5ac2c',1,'Applicazione::Contatto']]],
  ['setpreferito_10',['setPreferito',['../class_applicazione_1_1_contatto.html#ae4a5ae11e12508c554fb428f62134ba7',1,'Applicazione::Contatto']]],
  ['show_11',['show',['../class_applicazione_1_1_rubrica_controller.html#a84e690de465ea98fca2f8ee5df1fd1f0',1,'Applicazione::RubricaController']]],
  ['showarchivio_12',['showArchivio',['../class_applicazione_1_1_rubrica_controller.html#a0ef523db2bc45120b7ddc9e3bcfcb3c7',1,'Applicazione::RubricaController']]],
  ['sposta_13',['sposta',['../class_applicazione_1_1_archivio_controller.html#acaeeafa904b5c56ee8a60ffae75a2522',1,'Applicazione::ArchivioController']]],
  ['start_14',['start',['../class_applicazione_1_1_app.html#ae38e93564e84dd996a0070bb1d254507',1,'Applicazione::App']]]
];
