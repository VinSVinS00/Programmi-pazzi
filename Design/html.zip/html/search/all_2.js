var searchData=
[
  ['elimina_0',['elimina',['../class_applicazione_1_1_rubrica_controller.html#a93693dcdaaa530b4b76e48d40b604930',1,'Applicazione::RubricaController']]]
];
