var searchData=
[
  ['preferiticontroller_0',['PreferitiController',['../class_applicazione_1_1_preferiti_controller.html',1,'Applicazione']]]
];
