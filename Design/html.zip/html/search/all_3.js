var searchData=
[
  ['getcognome_0',['getCognome',['../class_applicazione_1_1_contatto.html#a86a67317043e97ade1b8088029025727',1,'Applicazione::Contatto']]],
  ['getmail_1',['getMail',['../class_applicazione_1_1_contatto.html#a34ad0cc92e47404f11182d26ad283a18',1,'Applicazione::Contatto']]],
  ['getmail2_2',['getMail2',['../class_applicazione_1_1_contatto.html#ad62fe5c38db112edb44d7155290b46c2',1,'Applicazione::Contatto']]],
  ['getmail3_3',['getMail3',['../class_applicazione_1_1_contatto.html#a8aadcace41f85e84e10914741453232e',1,'Applicazione::Contatto']]],
  ['getnome_4',['getNome',['../class_applicazione_1_1_contatto.html#a8f4a41173cef8c95bdc84c10d3ef50c9',1,'Applicazione::Contatto']]],
  ['getnumero_5',['getNumero',['../class_applicazione_1_1_contatto.html#ad6ac0667c803aacb68c9dae3e95cb7d9',1,'Applicazione::Contatto']]],
  ['getnumero2_6',['getNumero2',['../class_applicazione_1_1_contatto.html#a7781b9aab12342778d45bedc3de6bb46',1,'Applicazione::Contatto']]],
  ['getnumero3_7',['getNumero3',['../class_applicazione_1_1_contatto.html#aa878573588d226f2608db0247e43ec8f',1,'Applicazione::Contatto']]],
  ['getpreferito_8',['getPreferito',['../class_applicazione_1_1_contatto.html#a46d04fdaa89e52bbd9f1e075039be012',1,'Applicazione::Contatto']]]
];
