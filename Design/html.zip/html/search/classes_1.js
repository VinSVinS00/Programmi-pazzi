var searchData=
[
  ['contatto_0',['Contatto',['../class_applicazione_1_1_contatto.html',1,'Applicazione']]],
  ['contattocontroller_1',['ContattoController',['../class_applicazione_1_1_contatto_controller.html',1,'Applicazione']]]
];
