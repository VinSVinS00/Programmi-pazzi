var searchData=
[
  ['rubricacontroller_0',['RubricaController',['../class_applicazione_1_1_rubrica_controller.html',1,'Applicazione']]]
];
