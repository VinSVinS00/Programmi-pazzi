/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionerubrica;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Queue;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class RubricaController implements Initializable {
    
    private ObservableList<Contatto> oblist;
    private Contatto tempC;
    private Image icona = new Image(getClass().getResourceAsStream("icona.jpg"));

    @FXML
    private TableView<Contatto> base;
    @FXML
    private TableColumn<Contatto, String> basename;
    @FXML
    private TableColumn<Contatto, String> basecog;
    @FXML
    private TableColumn<Contatto, String> basenum;
    @FXML
    private TableColumn<Contatto, String> basemail;
    @FXML
    private Pane mainPain;
    @FXML
    private Pane paneAdd;
    @FXML
    private TextField txfname;
    @FXML
    private TextField txfcog;
    @FXML
    private TextField txfnum;
    @FXML
    private TextField txfmail;
    @FXML
    private Button butAdd;
    @FXML 
    private Button butSave;
    @FXML
    private Pane modPane;
    @FXML
    private TextField txfModName, txfModCog, txfModNum, txfModMail;
    @FXML
    private Button butModificaContatto;
    @FXML
    private Button butMod;
    @FXML
    private ImageView iconaView;
    @FXML
    private Label nomeContatto;
    @FXML
    private Button butDel;
    @FXML
    private Button butMostra;
    @FXML
    private TextField txfMail2;
    @FXML
    private TextField txfMail3;
    @FXML
    private TextField txfNum2;
    @FXML
    private TextField txfNum3;
    @FXML
    private Pane paneView;
    @FXML
    private Label lblname;
    @FXML
    private Label lblcog;
    @FXML
    private Label lbln1;
    @FXML
    private Label lbln2;
    @FXML
    private Label lbln3;
    @FXML
    private Label lblm1;
    @FXML
    private Label lblm2;
    @FXML
    private Label lblm3;
    @FXML
    private Button butBack;
    
    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        oblist = FXCollections.observableArrayList();
        
        basename.setCellValueFactory(new PropertyValueFactory<>("nome"));
        basecog.setCellValueFactory(new PropertyValueFactory<>("cognome"));
        basenum.setCellValueFactory(new PropertyValueFactory<>("numeri"));
        basemail.setCellValueFactory(new PropertyValueFactory<>("mail"));
        
        base.setItems(oblist);
    }

    @FXML
    public void add(ActionEvent event){
        if(event.getSource() == butAdd){
        base.setVisible(false);
        butAdd.setVisible(false);
        butDel.setVisible(false);
        butModificaContatto.setVisible(false);
        butMostra.setVisible(false);
        paneAdd.setVisible(true);
        }
    }

    @FXML
    public void salva(ActionEvent event) throws InterruptedException {
        if(event.getSource() == butSave){
        Alert alertname = new Alert(AlertType.INFORMATION);
        Alert alertnum = new Alert(AlertType.INFORMATION);
        alertnum.setTitle("ERRORE");
        alertnum.setContentText("numero errato");
        alertname.setTitle("ERRORE");
        alertname.setContentText("campi vuoti, reinserire");
        if(txfname.getText().isEmpty()){
            if(alertname.showAndWait().get() == ButtonType.OK){
                
            }
        }else if(txfnum.getText().length() != 10){
            if(alertnum.showAndWait().get() == ButtonType.OK){
                
            }
        }
        else
        {
        oblist.add(new Contatto(txfname.getText(), txfcog.getText(), txfnum.getText(), txfmail.getText()));
        FXCollections.sort(oblist, Comparator.comparing(Contatto::getNome));
        txfname.clear();
        txfcog.clear();
        txfnum.clear();
        txfmail.clear();
        base.setVisible(true);
        butAdd.setVisible(true);
        butModificaContatto.setVisible(true);
        butDel.setVisible(true);
        butMostra.setVisible(true);
        paneAdd.setVisible(false);
        }
        }
    }
    
    @FXML
    public void modificaContatto(ActionEvent event){
        if(event.getSource() == butModificaContatto){
        iconaView.setImage(icona);
        nomeContatto.setText(base.getSelectionModel().getSelectedItem().getNome() + " " + base.getSelectionModel().getSelectedItem().getCognome());
        tempC = base.getSelectionModel().getSelectedItem();
        txfModName.setText(tempC.getNome());
        txfModCog.setText(tempC.getCognome());
        txfModNum.setText(tempC.getNumeri());
        txfModMail.setText(tempC.getMail());
        if(!tempC.getMail2().isEmpty())
            txfMail2.setText(tempC.getMail2());
        if(!tempC.getMail3().isEmpty())
            txfMail3.setText(tempC.getMail3());
        if(!tempC.getNum2().isEmpty())
            txfNum2.setText(tempC.getNum2());
        if(!tempC.getNum3().isEmpty())
            txfNum3.setText(tempC.getNum3());
        base.setVisible(false);
        butModificaContatto.setVisible(false);
        butAdd.setVisible(false);
        butModificaContatto.setVisible(false);
        butDel.setVisible(false);
        butMostra.setVisible(false);
        modPane.setVisible(true);
        }
    }
    
    @FXML
    public void modifica(ActionEvent event){
        if(event.getSource() == butMod){
            
        Alert alertname = new Alert(AlertType.INFORMATION);
        Alert alertnum = new Alert(AlertType.INFORMATION);
        alertnum.setTitle("ERRORE");
        alertnum.setContentText("numero errato");
        alertname.setTitle("ERRORE");
        alertname.setContentText("campi vuoti, reinserire");
        if(txfModName.getText().isEmpty()){
            if(alertname.showAndWait().get() == ButtonType.OK){
                
            }
        }else if(txfModNum.getText().length() != 10){
            if(alertnum.showAndWait().get() == ButtonType.OK){
                
            }
        }
        else
            
        {
                for(int i=0; i<oblist.size(); i++){
                if(oblist.get(i).getNome().equalsIgnoreCase(tempC.getNome())){
                    oblist.remove(i);
                    oblist.add(new Contatto(txfModName.getText(), txfModCog.getText(), txfModNum.getText(), txfModMail.getText()));
                }
                }
            for(int i=0; i<oblist.size(); i++){
                if(oblist.get(i).getNome().equalsIgnoreCase(txfModName.getText())){
                if(!txfNum2.getText().isEmpty())
                    oblist.get(i).setNum2(txfNum2.getText());
                if(!txfNum3.getText().isEmpty())
                    oblist.get(i).setNum3(txfNum3.getText());
                if(!txfMail2.getText().isEmpty())
                    oblist.get(i).setMail2(txfMail2.getText());
                if(!txfMail3.getText().isEmpty())
                    oblist.get(i).setMail3(txfMail3.getText());
                }
            }
            modPane.setVisible(false);
            base.setVisible(true);
            butModificaContatto.setVisible(true);
            butAdd.setVisible(true);
            butMostra.setVisible(true);
            butDel.setVisible(true);
        }
    }
    }

    @FXML
    public void elimina(ActionEvent event) {
        if(event.getSource() == butDel)
        oblist.remove(base.getSelectionModel().getSelectedItem());
    }

    @FXML
    public void mostra(ActionEvent event) {
        if(event.getSource() == butMostra){
            lblname.setText(base.getSelectionModel().getSelectedItem().getNome());
            lblcog.setText(base.getSelectionModel().getSelectedItem().getCognome());
            lbln1.setText(base.getSelectionModel().getSelectedItem().getNumeri());
            lblm1.setText(base.getSelectionModel().getSelectedItem().getMail());
            
            
            base.setVisible(false);
            butModificaContatto.setVisible(false);
            butAdd.setVisible(false);
            butModificaContatto.setVisible(false);
            butDel.setVisible(false);
            butMostra.setVisible(false);
            paneView.setVisible(true);
        }
    }

    @FXML
    public void backRubr(ActionEvent event) {
        paneView.setVisible(false);
        base.setVisible(true);
        butModificaContatto.setVisible(true);
        butAdd.setVisible(true);
        butModificaContatto.setVisible(true);
        butDel.setVisible(true);
        butMostra.setVisible(true);
    }
    
    }
