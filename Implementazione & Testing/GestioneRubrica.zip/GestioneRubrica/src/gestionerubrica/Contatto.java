/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gestionerubrica;

import java.util.ArrayList;
import java.util.Queue;


public class Contatto {
    private String nome;
    private String cognome;
    private String numeri;
    private String mail;
    private String num2;
    private String num3;
    private String mail2;
    private String mail3;
    
    public Contatto(String nome, String cognome, String numeri, String mail, String num2, String num3, String mail2, String mail3) {
        this.nome = nome;
        this.cognome = cognome;
        this.numeri = numeri;
        this.mail = mail;
        this.num2 = num2;
        this.num3 = num3;
        this.mail2 = mail2;
        this.mail3 = mail3;
    }

    public String getNome() {
        return this.nome;
    }

    public String getCognome() {
        return this.cognome;
    }

    public String getNumeri() {
        return this.numeri;
    }

    public String getMail() {
        return this.mail;
    }

    public String getNum2() {
        return this.num2;
    }

    public String getNum3() {
        return this.num3;
    }

    public String getMail2() {
        return this.mail2;
    }

    public String getMail3() {
        return this.mail3;
    }
   
    
}
