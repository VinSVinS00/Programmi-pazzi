/* doesn't work with source level 1.8:
module Applicazione {
    requires javafx.controls;
    requires javafx.fxml;

    opens Applicazione to javafx.fxml;
    exports Applicazione;
}
*/
