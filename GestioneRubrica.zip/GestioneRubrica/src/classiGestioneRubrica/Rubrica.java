package classiGestioneRubrica;


import classiGestioneRubrica.InterfacciaRubrica;
import classiGestioneRubrica.Contatto;
import java.util.ArrayList;

public class Rubrica implements InterfacciaRubrica {

    private ArrayList<Contatto> rubrica;

    private String mail;

    private int memoriaMail;

    public Rubrica(String mail, int memoriaMail) {
        this.mail = mail;
        this.memoriaMail = memoriaMail;
    }

    

    public Contatto add(Contatto c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modificaNome(String n) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modificaCognome(String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modificaNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modicaMail(String mail) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Contatto cerca(String n, String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Contatto remove(String n, String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void mostraPreferiti() {
    }

    public String toString() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
