package classiGestioneRubrica;


import java.util.ArrayList;

public class Contatto {

    private String nome;

    private String cognome;

    private ArrayList<String> mail;

    private ArrayList<String> numero;

    private Boolean check;

    public Contatto(String nome, String cognome, Boolean check) {
        this.nome = nome;
        this.cognome = cognome;
        this.check = check;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    

    public String addNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String addMail(String m) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String removeNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String removeMail(String m) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Boolean addPreferiti(Boolean check) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Boolean removePrefetiri(Boolean check) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String toString() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
