package classiGestioneRubrica;


import classiGestioneRubrica.Contatto;
import java.util.ArrayList;

public class Gruppo implements InterfacciaRubrica {

    private String nome;

    private ArrayList<Contatto> gruppo;

    public Gruppo(String nome) {
        this.nome = nome;
    }

    

    public String modificaNome(String n) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modificaCognome(String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modificaNumero(String numero) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String modicaMail(String mail) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Contatto cerca(String n, String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Contatto remove(String n, String c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ArrayList sort(ArrayList a) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setNome(String n) {
    }
    

    public void add(Contatto c) {
    }

    public String toString() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
