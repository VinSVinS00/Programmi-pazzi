package classiGestioneRubrica;


import classiGestioneRubrica.Contatto;
import java.util.ArrayList;

public interface InterfacciaRubrica {

    public Contatto add(Contatto c);

    public String modificaNome(String n);

    public String modificaCognome(String c);

    public String modificaNumero(String numero);

    public String modicaMail(String mail);

    public Contatto cerca(String n, String c);

    public Contatto remove(String n, String c);

    public ArrayList sort(ArrayList a);

    public String toString();
}
