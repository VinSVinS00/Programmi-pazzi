package classiGestioneRubrica;


import java.util.ArrayList;

public class Archivio {

    private ArrayList<Contatto> archivio;

    public Archivio() {
    }

    public Contatto sposta(Contatto c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public Contatto remove(Contatto c) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public ArrayList sort(ArrayList a) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
